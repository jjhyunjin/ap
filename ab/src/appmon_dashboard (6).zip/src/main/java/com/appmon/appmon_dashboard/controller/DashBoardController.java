package com.appmon.appmon_dashboard.controller;


import com.appmon.appmon_dashboard.dto.elasticsearch.HitSource;
import com.appmon.appmon_dashboard.dto.elasticsearch.Result;
import com.appmon.appmon_dashboard.service.DashBoardService;
import com.google.gson.Gson;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.document.DocumentField;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class DashBoardController {

    @Autowired
    protected DashBoardService dashBoardService;

    private static final String VIEW_PATH = "dashboard/";
    private static final String COMPONENT_PATH = "component/";

    @RequestMapping( value = "/dashboard", method = RequestMethod.GET )
    public ModelAndView dashboard(Model model
            , @RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            , @RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){        return new ModelAndView(VIEW_PATH+"realtime_dashboard");    }


    @RequestMapping( value = "/dashboard/realtime/grape", method = RequestMethod.GET )
    @ResponseBody
    public  Collection<Histogram.Bucket> realTimeGrape(Model model
            , @RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            , @RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        Map<String, String> DateMap = getInitDate(startDate, endDate);
        SearchResponse searchResponse = dashBoardService.getRealtimeGrape(DateMap.get("startDate"), DateMap.get("endDate"));
        if(null != searchResponse){
            Histogram aggregations = searchResponse.getAggregations().get("agg");
            return  (Collection<Histogram.Bucket>) aggregations.getBuckets();
        }
       return null;
    }

    @RequestMapping( value = "/dashboard/realtime/table", method = RequestMethod.GET )
    @ResponseBody
    public ModelAndView realTimeTable(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        /*
        Map<String, String> DateMap = getInitDate(startDate, endDate);
        SearchResponse searchResponse = dashBoardService.getRealtimeTable(DateMap.get("startDate"), DateMap.get("endDate"));
        if(null != searchResponse){
            Result result = new Gson().fromJson(searchResponse.toString(), Result.class);
            return new ModelAndView(VIEW_PATH+COMPONENT_PATH+"realtime_table", "result", result.getHits().getHits());
        }
        return new ModelAndView(VIEW_PATH+COMPONENT_PATH+"realtime_table", "result", null);
        */

        Map<String, String> DateMap = getInitDate(startDate, endDate);
        List<SearchHit[]> searchResponse = dashBoardService.getRealtimeTable(DateMap.get("startDate"), DateMap.get("endDate"));


        List<HitSource> TotalHits = new ArrayList<HitSource>();
        if(!CollectionUtils.isEmpty(searchResponse)){
            for(SearchHit[] hits : searchResponse){
                for(SearchHit hit : hits){
                    HitSource source = new HitSource();
                    Map<String, Object> map = hit.getSourceAsMap();
                    source.setDevice_model( (String)map.get("device_model") );
                    source.setApp_gubun( (String)map.get("app_gubun") );
                    source.setOs_version( (String)map.get("os_version") );
                    source.setIp( (String)map.get("ip") );
                    source.setUuid( (String)map.get("uuid") );
                    source.setErr_message( (String)map.get("err_message") );
                    source.setErr_time( (String)map.get("err_time") );
                    source.setRefer( (String)map.get("refer") );
                    source.setErr_name( (String)map.get("err_name") );
                    source.setApp_ver( (String)map.get("app_ver") );
                    source.setDevice_gubun( (String)map.get("device_gubun") );
                    source.setNetwork_type( (String)map.get("network_type") );
                    source.setCustomer_id( (String)map.get("customer_id") );
                    TotalHits.add(source);
                }
            }
        }
        if(null != TotalHits){
            return new ModelAndView(VIEW_PATH+COMPONENT_PATH+"realtime_table", "hits", TotalHits);
        }
        return new ModelAndView(VIEW_PATH+COMPONENT_PATH+"realtime_table", "hits", null);

    }

    private Map<String, String> getInitDate(String startDate, String endDate){
        Map<String, String> map = new HashMap<String, String>();
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            cal.add(Calendar.MINUTE, -10);
            startDate = sdf.format(cal.getTime());
        }
        map.put("startDate", startDate);
        map.put("endDate", endDate);
        return map;
    }

}
