package com.appmon.appmon_dashboard.service;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;

import java.util.List;

public interface DashBoardService {
    //SearchResponse getRealtimeTable(String startDate, String endDate);
    List<SearchHit[]> getRealtimeTable(String startDate, String endDate);
    SearchResponse getRealtimeGrape(String startDate, String endDate);
}
