package com.appmon.appmon_dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppmonDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppmonDashboardApplication.class, args);
	}
}
