package com.appmon.appmon_dashboard.service;

import com.appmon.appmon_dashboard.dto.elasticsearch.HitBlock;
import com.appmon.appmon_dashboard.dto.elasticsearch.HitSource;
import com.appmon.appmon_dashboard.dto.elasticsearch.Result;
import com.google.gson.Gson;
import org.apache.http.HttpHost;
import org.elasticsearch.action.search.*;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.Scroll;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.ExtendedBounds;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

@Service
public class DashBoardServiceImpl implements DashBoardService {
/*
    @Override
    public SearchResponse getRealtimeTable(String startDate, String endDate) {
        try {
            RestHighLevelClient client = new RestHighLevelClient(
                    RestClient.builder(
                            new HttpHost("220.230.121.6", 9200)));

            String sDate = String.valueOf(timestampToString(startDate));
            String eDate = String.valueOf(timestampToString(endDate));

            SearchRequest searchRequest = new SearchRequest("appmon*");
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(QueryBuilders.rangeQuery("@timestamp").to(eDate).from(sDate));
            searchRequest.source(searchSourceBuilder);
            SearchResponse searchResponse = client.search(searchRequest);

            client.close();
            return searchResponse;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
*/
    @Override
    public SearchResponse getRealtimeGrape(String startDate, String endDate) {
        try {
            RestHighLevelClient client = new RestHighLevelClient(
                    RestClient.builder(
                            new HttpHost("220.230.121.6", 9200)));

            String sDate = String.valueOf(timestampToString(startDate));
            String eDate = String.valueOf(timestampToString(endDate));

            SearchRequest searchRequest = new SearchRequest("appmon*");
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(QueryBuilders.rangeQuery("@timestamp").to(eDate).from(sDate));
            ExtendedBounds extendedBounds = new ExtendedBounds(sDate, eDate);
            AggregationBuilder aggregation =
                    AggregationBuilders
                            .dateHistogram("agg")
                            .field("@timestamp")
                            .minDocCount(0)
                            .extendedBounds(extendedBounds)
                            .dateHistogramInterval(DateHistogramInterval.MINUTE);
            searchSourceBuilder.aggregation(aggregation);
            searchRequest.source(searchSourceBuilder);
            SearchResponse searchResponse = client.search(searchRequest);

            //System.out.println("response[getRealtimeGrape] : " + searchResponse.toString());

            client.close();
            return searchResponse;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*
    private LocalDateTime timestampToString(String date){
        Calendar cal;
        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
        try{
            sd.parse(date);
        }catch(ParseException e){
            e.printStackTrace();
        }
        cal = sd.getCalendar();
        //System.out.println("timestamp : " + new Timestamp(cal.getTime().getTime()).toLocalDateTime());
        return new Timestamp(cal.getTime().getTime()).toLocalDateTime();
    }
    */

    private LocalDateTime timestampToString(String date){
        Calendar cal;
        SimpleDateFormat sd = new SimpleDateFormat("yyyyMMddHHmmss");
        try{
            sd.parse(date);
        }catch(ParseException e){
            e.printStackTrace();
        }
        cal = sd.getCalendar();
        cal.add(Calendar.HOUR, -9);
        //System.out.println("timestamp : " + new Timestamp(cal.getTime().getTime()).toLocalDateTime());
        return new Timestamp(cal.getTime().getTime()).toLocalDateTime();
    }

    @Override
    public List<SearchHit[]> getRealtimeTable(String startDate, String endDate) {
        try {
            RestHighLevelClient client = new RestHighLevelClient(
                    RestClient.builder(
                            new HttpHost("220.230.121.6", 9200)));

            String sDate = String.valueOf(timestampToString(startDate));
            String eDate = String.valueOf(timestampToString(endDate));

            final Scroll scroll = new Scroll(TimeValue.timeValueMinutes(1L));
            SearchRequest searchRequest = new SearchRequest("appmon*");
            searchRequest.scroll(scroll);

            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.query(QueryBuilders.rangeQuery("@timestamp").to(eDate).from(sDate));
            searchRequest.source(searchSourceBuilder);

            SearchResponse searchResponse = client.search(searchRequest);

            String scrollId = searchResponse.getScrollId();
            List<SearchHit[]> totalHits = new ArrayList<SearchHit[]>();
            SearchHit[] searchHits = searchResponse.getHits().getHits();
            totalHits.add(searchHits);
            System.out.println("searchHits : " + searchHits.toString());
            while (searchHits != null && searchHits.length > 0) {
                SearchScrollRequest scrollRequest = new SearchScrollRequest(scrollId);
                scrollRequest.scroll(scroll);
                searchResponse = client.searchScroll(scrollRequest);
                scrollId = searchResponse.getScrollId();
                searchHits = searchResponse.getHits().getHits();
                totalHits.add(searchHits);
            }

            ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
            clearScrollRequest.addScrollId(scrollId);
            ClearScrollResponse clearScrollResponse = client.clearScroll(clearScrollRequest);
            boolean succeeded = clearScrollResponse.isSucceeded();

            System.out.println("ClearScrollRequest 성공여부 : " + succeeded);

            client.close();

            //return searchResponse;
            return totalHits;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



}
